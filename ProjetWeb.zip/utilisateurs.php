<?php $utilisateurs = array (
  0 => 
  array (
    'pseudo' => 'Saf',
    'motdepasse' => '$2y$10$Hj0xF6tL0M9RlKHq/w9mbe0rpTORxeGOXeg.s3mcekfoZ/4PWlGJ2',
  ),
); ?>